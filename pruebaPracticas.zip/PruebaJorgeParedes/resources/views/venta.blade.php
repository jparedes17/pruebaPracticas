@extends('main')
@section('seccion')

<div class="col-sm-9">
          <div class="well">
          <div class="container">
  <h2>Tabla Ventas</h2>
  <div class="col-sm-7">
  <div class="table-responsive">           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>SalesOrderID</th>
        <th>OrderDate</th>
        <th>SalesOrderNumber</th>
        <th>PurchaseOrderNumber</th>
        <th>CustomerID</th>
      </tr>
    </thead>

  </table>
</div>
          </div>
</div>
          </div>
</div>

@endsection