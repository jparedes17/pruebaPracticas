
<?php $__env->startSection('seccion'); ?>

<div class="col-sm-9">
          <div class="well">
          <div class="container">
  <h2>Tabla Ventas</h2>
  <div class="col-sm-7">
  <div class="table-responsive">           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>SalesOrderID</th>
        <th>OrderDate</th>
        <th>SalesOrderNumber</th>
        <th>PurchaseOrderNumber</th>
        <th>CustomerID</th>
      </tr>
    </thead>

  </table>
</div>
          </div>
</div>
          </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PruebaJorgeParedes\resources\views/venta.blade.php ENDPATH**/ ?>