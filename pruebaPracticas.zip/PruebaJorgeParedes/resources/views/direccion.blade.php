@extends('main')
@section('seccion')

<div class="col-sm-9">
          <div class="well">
          <div class="container">
  <h2>Tabla Direcciones</h2>
  <div class="col-sm-7">
  <div class="table-responsive">           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>AddressID</th>
        <th>AddressLine</th>
        <th>City</th>
        <th>StateProvince</th>
        <th>PostalCode</th>
      </tr>
    </thead>
  </table>
</div>
          </div>
</div>
          </div>
</div>


@endsection