
<?php $__env->startSection('seccion'); ?>

<div class="col-sm-9">
          <div class="well">
          <div class="container">
  <h2>Tabla Direcciones</h2>
  <div class="col-sm-7">
  <div class="table-responsive">           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>AddressID</th>
        <th>AddressLine</th>
        <th>City</th>
        <th>StateProvince</th>
        <th>PostalCode</th>
      </tr>
    </thead>
  </table>
</div>
          </div>
</div>
          </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PruebaJorgeParedes\resources\views/direccion.blade.php ENDPATH**/ ?>